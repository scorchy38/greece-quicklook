// swift-tools-version: 6.0
import PackageDescription

let package = Package(name: "Atlas", targets: [.target(name: "Atlas"), .testTarget(name: "AtlasTests", dependencies: ["Atlas"])])
