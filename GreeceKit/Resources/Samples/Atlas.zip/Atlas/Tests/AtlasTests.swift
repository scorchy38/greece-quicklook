import XCTest

final class AtlasTests: XCTestCase {
    func testRoute() {}
}
