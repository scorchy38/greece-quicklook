"""Assigns berths to ferries arriving at Aegean harbours."""

__version__ = "2.4.1"

def assign(ship, harbour):
    return harbour.free_berths()[0]
