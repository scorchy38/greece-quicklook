BERTHS = ['A1', 'A2', 'B1']
